package dev.fristone.backpack;

/** 简单记录（体积、质量、形态） */
public record ItemMetrics(double vol, double mass, String form) {}